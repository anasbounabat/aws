// src/lambda.ts
app.get("*", (c) => {
  return c.json({
    status: "Hono est vivant",
    receivedPath: c.req.path,
    message: "Si tu vois ça, l'infra AWS est OK, c'est juste un problème de routes !"
  });
});
